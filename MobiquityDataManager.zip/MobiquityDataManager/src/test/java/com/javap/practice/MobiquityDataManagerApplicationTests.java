package com.javap.practice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MobiquityDataManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}

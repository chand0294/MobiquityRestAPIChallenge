package com.javap.model;




public class OpeningHours {
	int dayOfWeek;
	Hours[]	hours;
	public int getDayOfWeek() {
		return dayOfWeek;
	}
	public void setDayOfWeek(int dayOfWeek) {
		this.dayOfWeek = dayOfWeek;
	}
	public Hours[] getHours() {
		return hours;
	}
	public void setHours(Hours[] hours) {
		this.hours = hours;
	}
	
	

}

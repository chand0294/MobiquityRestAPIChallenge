package com.javap.rest;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.javap.model.AtmAddress;
import com.javap.model.AtmModel;
import com.javap.model.GeoLocation;
import com.javap.model.OpeningHours;


@CrossOrigin(value="*")
@RestController
@RequestMapping("/api")
public class MDMDataController {
	
	
	private static final String GET_ATM_LIST = "https://www.ing.nl/api/locator/atms/";
	private static final String GET_ATM_BY_CITY = "https://www.ing.nl/api/locator/atms/{city}";
	
	
	public RestTemplate getRestTemplate(){
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
		restTemplate.getMessageConverters().add(0, new StringHttpMessageConverter(Charset.forName("UTF-8")));
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		return restTemplate;
	}
	
	@GetMapping(value="/check")
	public String getResponse(){
		return "Hello Mobiquity !";
		
	}

	@GetMapping(value="/getATMList")
	public ResponseEntity<List<AtmModel>> getATMList(){
		

		List<AtmModel> atmList=new ArrayList<>();
		HttpHeaders responseHeaders=new HttpHeaders();
		responseHeaders.add("Content-Type", "application/json; charset=utf-8");
		
		List<String> lst = new ArrayList<>();
		RestTemplate restTemplate = getRestTemplate();

		ResponseEntity<String> res = restTemplate.getForEntity(GET_ATM_LIST, String.class);

		atmList=this.processJSON(res,null);
		
		return new ResponseEntity<List<AtmModel>>(atmList, responseHeaders, HttpStatus.OK);
		
	}
	
	
	@GetMapping(value="/getATMList/filterBycityName/{city}")
	public ResponseEntity<List<AtmModel>> filterATMbyCity(@PathVariable("city") String city){
		
		List<AtmModel> atmList=new ArrayList<>();
		HttpHeaders responseHeaders=new HttpHeaders();
		responseHeaders.add("Content-Type", "application/json; charset=utf-8");
		
		List<String> lst = new ArrayList<>();
		RestTemplate restTemplate = getRestTemplate();

		ResponseEntity<String> res = restTemplate.getForEntity(GET_ATM_LIST, String.class);

		atmList=this.processJSON(res,city);
		
		
		return new ResponseEntity<List<AtmModel>>(atmList, responseHeaders, HttpStatus.OK);
		
	}
	
	

	
	public List<AtmModel> processJSON(ResponseEntity<String> res, String city){
		List<AtmModel> lst=new ArrayList<>();

		String[] parts=res.getBody().split("\\}',");
		String correctedStringData=parts[1];
		try {

			JSONArray jsonArray=new JSONArray(correctedStringData);
			for(Object o:jsonArray) {
				
				AtmModel atm=new AtmModel();
				
				JSONObject jsonObject=(JSONObject)o;
				String type = (String) jsonObject.get("type");
				
				JSONObject jsonObjectAddress=(JSONObject)jsonObject.get("address");
				AtmAddress address=new AtmAddress();
				address.setStreet((String)jsonObjectAddress.get("street"));
				address.setHousenumber((String)jsonObjectAddress.get("housenumber"));
				address.setPostalcode((String)jsonObjectAddress.get("postalcode"));
				address.setCity((String)jsonObjectAddress.get("city"));
				
				JSONObject jsonObjectGeoLoc=(JSONObject)jsonObjectAddress.get("geoLocation");
				GeoLocation geoLocation=new GeoLocation();
				geoLocation.setLat((String)jsonObjectGeoLoc.get("lat"));
				geoLocation.setLng((String)jsonObjectGeoLoc.get("lng"));
				address.setGeoLocation(geoLocation);

				atm.setAddress(address);			
				atm.setDistance((Integer) jsonObject.get("distance"));
				//atm.setOpeningHours((OpeningHours[]) jsonObject.get("openingHours"));
				atm.setFunctionality((String) jsonObject.get("functionality"));
				atm.setType((String) jsonObject.get("type"));				
				lst.add(atm);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		if(city!=null) {
			lst=lst.stream()
					.filter((atm)-> city.equals(atm.getAddress().getCity()))
					.collect(Collectors.toList());
		}
		
		return lst;
		
		
	} 
	

	
}
